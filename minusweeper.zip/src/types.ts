/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type GameDifficulty = 'easy' | 'medium' | 'hard' | 'custom';

export interface DifficultyConfig {
  name: string;
  rows: number;
  cols: number;
  positiveBombs: number;
  negativeBombs: number;
}

export type FlagState = 'none' | 'positive' | 'negative' | 'question';

export interface Cell {
  row: number;
  col: number;
  isBomb: boolean;          // Positive Bomb (+1)
  isNegativeBomb: boolean;  // Negative Bomb (-1)
  isRevealed: boolean;
  flagState: FlagState;
  neighborValue: number;    // Adjacent positive bombs count - adjacent negative bombs count
  adjacentPositive: number; // Count of adjacent positive bombs
  adjacentNegative: number; // Count of adjacent negative bombs
}

export type GameStatus = 'idle' | 'playing' | 'won' | 'lost';
