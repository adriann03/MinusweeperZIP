/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Cell, DifficultyConfig, GameDifficulty } from '../types';

export const DIFFICULTIES: Record<Exclude<GameDifficulty, 'custom'>, DifficultyConfig> = {
  easy: {
    name: 'Easy',
    rows: 9,
    cols: 9,
    positiveBombs: 10,
    negativeBombs: 4,
  },
  medium: {
    name: 'Medium',
    rows: 15,
    cols: 15,
    positiveBombs: 30,
    negativeBombs: 12,
  },
  hard: {
    name: 'Expert',
    rows: 16,
    cols: 30,
    positiveBombs: 70,
    negativeBombs: 25,
  },
};

export function createEmptyBoard(rows: number, cols: number): Cell[][] {
  const board: Cell[][] = [];
  for (let r = 0; r < rows; r++) {
    const rowCells: Cell[] = [];
    for (let c = 0; c < cols; c++) {
      rowCells.push({
        row: r,
        col: c,
        isBomb: false,
        isNegativeBomb: false,
        isRevealed: false,
        flagState: 'none',
        neighborValue: 0,
        adjacentPositive: 0,
        adjacentNegative: 0,
      });
    }
    board.push(rowCells);
  }
  return board;
}

export function populateBoardWithBombs(
  board: Cell[][],
  startRow: number,
  startCol: number,
  positiveCount: number,
  negativeCount: number
): Cell[][] {
  const rows = board.length;
  const cols = board[0].length;
  const totalCells = rows * cols;

  // Make a list of all positions
  const positions: { r: number; c: number }[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      positions.push({ r, c });
    }
  }

  // Define the safe area (3x3 grid around start).
  // If we don't have enough cells for this, limit it to just the start cell.
  let isCellSafe = (r: number, c: number) => {
    return Math.abs(r - startRow) <= 1 && Math.abs(c - startCol) <= 1;
  };

  const safePositionsCount = positions.filter((pos) => isCellSafe(pos.r, pos.c)).length;
  const bombsNeeded = positiveCount + negativeCount;

  if (totalCells - safePositionsCount < bombsNeeded) {
    // Fallback: only the start cell itself is guaranteed safe
    isCellSafe = (r: number, c: number) => r === startRow && c === startCol;
  }

  // Filter out safe spots
  const bombCandidates = positions.filter((pos) => !isCellSafe(pos.r, pos.c));

  // Shuffle the candidates using Floyd-Rivest or simple Fisher-Yates
  for (let i = bombCandidates.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = bombCandidates[i];
    bombCandidates[i] = bombCandidates[j];
    bombCandidates[j] = temp;
  }

  // Deploy positive bombs
  const actualPositivePlaced = Math.min(positiveCount, bombCandidates.length);
  for (let i = 0; i < actualPositivePlaced; i++) {
    const pos = bombCandidates[i];
    board[pos.r][pos.c].isBomb = true;
  }

  // Deploy negative bombs
  const actualNegativePlaced = Math.min(
    negativeCount,
    bombCandidates.length - actualPositivePlaced
  );
  for (let i = 0; i < actualNegativePlaced; i++) {
    const pos = bombCandidates[actualPositivePlaced + i];
    board[pos.r][pos.c].isNegativeBomb = true;
  }

  // Standardize values
  recalculateNumbers(board);

  return board;
}

export function recalculateNumbers(board: Cell[][]): void {
  const rows = board.length;
  const cols = board[0].length;

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const cell = board[r][c];
      if (cell.isBomb || cell.isNegativeBomb) {
        cell.neighborValue = 0;
        cell.adjacentPositive = 0;
        cell.adjacentNegative = 0;
        continue;
      }

      let posCount = 0;
      let negCount = 0;

      // Check all 8 directions
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = r + dr;
          const nc = c + dc;

          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
            const neighbor = board[nr][nc];
            if (neighbor.isBomb) {
              posCount++;
            } else if (neighbor.isNegativeBomb) {
              negCount++;
            }
          }
        }
      }

      cell.adjacentPositive = posCount;
      cell.adjacentNegative = negCount;
      // Formula: positive bombs add 1, negative bombs subtract 1.
      cell.neighborValue = posCount - negCount;
    }
  }
}

/**
 * Flood-fill helper to reveal cells starting from (row, col)
 */
export function revealCellMutation(board: Cell[][], row: number, col: number): { revealedCount: number; exploded: boolean } {
  const rows = board.length;
  const cols = board[0].length;
  const target = board[row][col];

  if (target.isRevealed || target.flagState === 'positive' || target.flagState === 'negative') {
    return { revealedCount: 0, exploded: false };
  }

  // If clicked a bomb, game over!
  if (target.isBomb || target.isNegativeBomb) {
    target.isRevealed = true;
    return { revealedCount: 1, exploded: true };
  }

  let count = 0;
  const queue: { r: number; c: number }[] = [{ r: row, c: col }];

  while (queue.length > 0) {
    const curr = queue.shift()!;
    const cell = board[curr.r][curr.c];

    if (cell.isRevealed || cell.flagState === 'positive' || cell.flagState === 'negative') continue;

    cell.isRevealed = true;
    count++;

    // Only auto-expand cells that are TRUE ZERO (absolutely no positive and no negative bombs in adjacent cells)
    if (cell.adjacentPositive === 0 && cell.adjacentNegative === 0) {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const nr = curr.r + dr;
          const nc = curr.c + dc;

          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
            const neighbor = board[nr][nc];
            if (!neighbor.isRevealed && neighbor.flagState !== 'positive' && neighbor.flagState !== 'negative') {
              queue.push({ r: nr, c: nc });
            }
          }
        }
      }
    }
  }

  return { revealedCount: count, exploded: false };
}

/**
 * Perform a "chord" click on a revealed cell.
 * If the flanking flags exactly match the flanking bomb counts, reveal the rest.
 */
export function chordCellMutation(
  board: Cell[][],
  row: number,
  col: number
): { cellsRevealed: number; exploded: boolean; explodedRow?: number; explodedCol?: number } {
  const rows = board.length;
  const cols = board[0].length;
  const target = board[row][col];

  if (!target.isRevealed || (target.adjacentPositive === 0 && target.adjacentNegative === 0)) {
    return { cellsRevealed: 0, exploded: false };
  }

  // Count flags around
  let positiveFlags = 0;
  let negativeFlags = 0;

  for (let dr = -1; dr <= 1; dr++) {
    for (let dc = -1; dc <= 1; dc++) {
      if (dr === 0 && dc === 0) continue;
      const nr = row + dr;
      const nc = col + dc;
      if (nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
        const flag = board[nr][nc].flagState;
        if (flag === 'positive') positiveFlags++;
        if (flag === 'negative') negativeFlags++;
      }
    }
  }

  // Chord works if flags perfectly match bomb counts
  if (positiveFlags === target.adjacentPositive && negativeFlags === target.adjacentNegative) {
    let cellsRevealed = 0;
    let exploded = false;
    let explodedRow: number | undefined;
    let explodedCol: number | undefined;

    // Open any standard unrevealed neighbor that is NOT flagged
    for (let dr = -1; dr <= 1; dr++) {
      for (let dc = -1; dc <= 1; dc++) {
        if (dr === 0 && dc === 0) continue;
        const nr = row + dr;
        const nc = col + dc;
        if (nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
          const neighbor = board[nr][nc];
          if (!neighbor.isRevealed && neighbor.flagState !== 'positive' && neighbor.flagState !== 'negative') {
            const outcome = revealCellMutation(board, nr, nc);
            cellsRevealed += outcome.revealedCount;
            if (outcome.exploded) {
              exploded = true;
              explodedRow = nr;
              explodedCol = nc;
            }
          }
        }
      }
    }

    return { cellsRevealed, exploded, explodedRow, explodedCol };
  }

  return { cellsRevealed: 0, exploded: false };
}

/**
 * Revel all bombs on game over
 */
export function revealAllBombs(board: Cell[][], explodedRow?: number, explodedCol?: number): void {
  for (let r = 0; r < board.length; r++) {
    for (let c = 0; c < board[0].length; c++) {
      const cell = board[r][c];
      if (cell.isBomb || cell.isNegativeBomb) {
        // Only mark revealed if it wasn't already flagged, to show correct/incorrect flags
        if (cell.flagState === 'none' || cell.flagState === 'question') {
          cell.isRevealed = true;
        }
      } else {
        // Cell is NOT a bomb, but player flagged it as a bomb (incorrect flag!)
        // We will keep flag but we can show cross/error in UI
      }
    }
  }
}
