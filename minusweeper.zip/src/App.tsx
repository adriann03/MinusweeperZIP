/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import MinesweeperCore from './components/MinesweeperCore';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-800 select-none flex flex-col">
      <MinesweeperCore />
    </div>
  );
}


