/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Bomb,
  Flag,
  RotateCw,
  Volume2,
  VolumeX,
  Clock,
  Settings,
  HelpCircle,
  Trophy,
  Layout,
  MousePointer,
  ChevronRight,
  Info
} from 'lucide-react';
import { Cell, GameDifficulty, GameStatus, DifficultyConfig, FlagState } from '../types';
import {
  DIFFICULTIES,
  createEmptyBoard,
  populateBoardWithBombs,
  revealCellMutation,
  chordCellMutation,
  revealAllBombs,
  recalculateNumbers
} from '../utils/gameLogic';
import { sound } from '../utils/audio';
import HowToPlay from './HowToPlay';

export default function MinesweeperCore() {
  // Game Configuration Parameters
  const [difficulty, setDifficulty] = useState<GameDifficulty>('easy');
  const [customRows, setCustomRows] = useState<number>(10);
  const [customCols, setCustomCols] = useState<number>(10);
  const [customPosBombs, setCustomPosBombs] = useState<number>(12);
  const [customNegBombs, setCustomNegBombs] = useState<number>(4);
  const [showCustomConfig, setShowCustomConfig] = useState<boolean>(false);

  // Core Game State
  const [board, setBoard] = useState<Cell[][]>([]);
  const [gameStatus, setGameStatus] = useState<GameStatus>('idle');
  const [firstClick, setFirstClick] = useState<boolean>(true);
  const [time, setTime] = useState<number>(0);

  // Flags & Left Click Behavior
  const [activeTool, setActiveTool] = useState<'dig' | 'flag-positive' | 'flag-negative'>('dig');
  const [cellSize, setCellSize] = useState<number>(36); // px

  // High Scores & Info Modal
  const [highScores, setHighScores] = useState<Record<string, number>>({});
  const [showHowTo, setShowHowTo] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);

  // Refs for Game Loop / Face Tracking
  const [isClickingCell, setIsClickingCell] = useState<boolean>(false);
  const [explodedCell, setExplodedCell] = useState<{ row: number; col: number } | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Get active config boundaries
  const activeConfig = (() => {
    if (difficulty === 'custom') {
      return {
        name: 'Custom',
        rows: customRows,
        cols: customCols,
        positiveBombs: customPosBombs,
        negativeBombs: customNegBombs
      };
    }
    return DIFFICULTIES[difficulty];
  })();

  // Initialize sounds and read high scores on mount
  useEffect(() => {
    const scores: Record<string, number> = {};
    ['easy', 'medium', 'hard'].forEach((mode) => {
      const saved = localStorage.getItem(`minesweeper_neg_score_${mode}`);
      if (saved) {
        scores[mode] = parseInt(saved, 10);
      }
    });
    setHighScores(scores);

    // Audio initial setup
    const savedMute = localStorage.getItem('minesweeper_neg_mute') === 'true';
    setIsMuted(savedMute);
    sound.isMuted = savedMute;
  }, []);

  // Sync mute state
  const handleToggleMute = () => {
    const newMuted = !isMuted;
    setIsMuted(newMuted);
    sound.isMuted = newMuted;
    localStorage.setItem('minesweeper_neg_mute', String(newMuted));
    sound.playClick();
  };

  // Timer effect
  useEffect(() => {
    if (gameStatus === 'playing') {
      timerRef.current = setInterval(() => {
        setTime((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [gameStatus]);

  // Handle board initialization/reset
  const initGame = (targetDiff = difficulty) => {
    const config = targetDiff === 'custom'
      ? { rows: customRows, cols: customCols, positiveBombs: customPosBombs, negativeBombs: customNegBombs }
      : DIFFICULTIES[targetDiff];

    const empty = createEmptyBoard(config.rows, config.cols);
    setBoard(empty);
    setGameStatus('idle');
    setExplodedCell(null);
    setFirstClick(true);
    setTime(0);
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
  };

  // Trigger init board when configuration/difficulty updates
  useEffect(() => {
    initGame();
  }, [difficulty]);

  // Adjust custom sliders safely inside logic bounds
  const handleCustomConfirm = () => {
    setShowCustomConfig(false);
    initGame('custom');
  };

  // Check absolute grid capacity for bombs
  const maxBombsForCustom = Math.max(2, Math.floor((customRows * customCols) * 0.7));

  // Counts of flags actually deployed
  const counts = (() => {
    let posFlags = 0;
    let negFlags = 0;
    board.forEach((row) => {
      row.forEach((cell) => {
        if (cell.flagState === 'positive') posFlags++;
        if (cell.flagState === 'negative') negFlags++;
      });
    });
    return { posFlags, negFlags };
  })();

  // Main cell reveal logic (Left-Click or Tap in Dig Mode)
  const handleReveal = (r: number, c: number) => {
    if (gameStatus === 'lost' || gameStatus === 'won') return;

    let currentBoard = [...board.map((row) => [...row])];
    let cell = currentBoard[r][c];

    // If flagged, prevent accidental click
    if (cell.flagState === 'positive' || cell.flagState === 'negative') {
      return;
    }

    // Lazy generation on first click
    if (firstClick) {
      currentBoard = populateBoardWithBombs(
        currentBoard,
        r,
        c,
        activeConfig.positiveBombs,
        activeConfig.negativeBombs
      );
      setBoard(currentBoard);
      setFirstClick(false);
      setGameStatus('playing');
      sound.playClick();

      // Proceed with revealing on the freshly generated board
      revealAndCheckWin(currentBoard, r, c);
      return;
    }

    sound.playClick();
    revealAndCheckWin(currentBoard, r, c);
  };

  const revealAndCheckWin = (currentBoard: Cell[][], r: number, c: number) => {
    const outcome = revealCellMutation(currentBoard, r, c);

    if (outcome.exploded) {
      // Exploded! Reveal all bombs and stop
      setExplodedCell({ row: r, col: c });
      revealAllBombs(currentBoard, r, c);
      setBoard(currentBoard);
      setGameStatus('lost');
      sound.playExplosion();
      return;
    }

    // Check Win Condition
    setBoard(currentBoard);
    checkWin(currentBoard);
  };

  // Check if remaining covered safe cells are 0
  const checkWin = (currentBoard: Cell[][]) => {
    const rows = currentBoard.length;
    const cols = currentBoard[0].length;
    let totalSafeCells = 0;
    let revealedSafeCells = 0;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const cell = currentBoard[r][c];
        if (!cell.isBomb && !cell.isNegativeBomb) {
          totalSafeCells++;
          if (cell.isRevealed) {
            revealedSafeCells++;
          }
        }
      }
    }

    if (revealedSafeCells === totalSafeCells && totalSafeCells > 0) {
      setGameStatus('won');
      sound.playWin();

      // Auto-flag all correct bombs for clean visual finish
      const finalBoard = currentBoard.map((row) =>
        row.map((cell) => {
          if (cell.isBomb) return { ...cell, flagState: 'positive' as FlagState };
          if (cell.isNegativeBomb) return { ...cell, flagState: 'negative' as FlagState };
          return cell;
        })
      );
      setBoard(finalBoard);

      // Save High Score for presets
      if (difficulty !== 'custom') {
        const currentBest = highScores[difficulty];
        if (!currentBest || time < currentBest) {
          localStorage.setItem(`minesweeper_neg_score_${difficulty}`, String(time));
          setHighScores((prev) => ({ ...prev, [difficulty]: time }));
        }
      }
    }
  };

  // Cycling Cell Flag States (Right Click)
  const handleFlagCycle = (r: number, c: number, e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    if (gameStatus === 'lost' || gameStatus === 'won') return;

    const currentBoard = board.map((row) => row.map((cell) => ({ ...cell })));
    const cell = currentBoard[r][c];

    if (cell.isRevealed) {
      // Chord reveal mechanism when clicking on a revealed tile
      handleChord(r, c);
      return;
    }

    let nextState: FlagState = 'none';
    if (cell.flagState === 'none') {
      nextState = 'positive';
    } else if (cell.flagState === 'positive') {
      nextState = 'negative';
    } else if (cell.flagState === 'negative') {
      nextState = 'question';
    } else if (cell.flagState === 'question') {
      nextState = 'none';
    }

    cell.flagState = nextState;
    setBoard(currentBoard);
    sound.playFlag();
  };

  // Handle chord option for custom clicking / chord click
  const handleChord = (r: number, c: number) => {
    if (gameStatus === 'lost' || gameStatus === 'won') return;

    const currentBoard = board.map((row) => row.map((cell) => ({ ...cell })));
    const outcome = chordCellMutation(currentBoard, r, c);

    if (outcome.cellsRevealed > 0) {
      if (outcome.exploded) {
        setExplodedCell({ row: outcome.explodedRow ?? r, col: outcome.explodedCol ?? c });
        revealAllBombs(currentBoard, outcome.explodedRow, outcome.explodedCol);
        setBoard(currentBoard);
        setGameStatus('lost');
        sound.playExplosion();
      } else {
        setBoard(currentBoard);
        checkWin(currentBoard);
        sound.playClick();
      }
    }
  };

  // Touch / Mobile friendly single-tool action
  const handleCellPrimaryAction = (r: number, c: number) => {
    if (activeTool === 'dig') {
      handleReveal(r, c);
    } else if (activeTool === 'flag-positive') {
      toggleFlagSpecific(r, c, 'positive');
    } else if (activeTool === 'flag-negative') {
      toggleFlagSpecific(r, c, 'negative');
    }
  };

  const toggleFlagSpecific = (r: number, c: number, flagType: 'positive' | 'negative') => {
    if (gameStatus === 'lost' || gameStatus === 'won') return;
    const currentBoard = board.map((row) => row.map((cell) => ({ ...cell })));
    const cell = currentBoard[r][c];

    if (cell.isRevealed) return;

    if (cell.flagState === flagType) {
      cell.flagState = 'none';
    } else {
      cell.flagState = flagType;
    }

    setBoard(currentBoard);
    sound.playFlag();
  };

  // Smiley code check
  const getSmileyFace = () => {
    if (gameStatus === 'lost') return '😵';
    if (gameStatus === 'won') return '😎';
    if (isClickingCell) return '😮';
    return '🙂';
  };

  // Styling helpers for numbers
  const getCellTextColorClass = (val: number) => {
    if (val === 1) return 'text-sky-400 font-extrabold';
    if (val === 2) return 'text-emerald-400 font-extrabold';
    if (val === 3) return 'text-rose-450 font-extrabold';
    if (val === 4) return 'text-indigo-400 font-extrabold';
    if (val === 5) return 'text-amber-600 font-extrabold';
    if (val === 6) return 'text-teal-400 font-extrabold';
    if (val === 7) return 'text-purple-400 font-extrabold';
    if (val === 8) return 'text-slate-200 font-extrabold';

    // Negatives
    if (val === -1) return 'text-violet-400 font-extrabold';
    if (val === -2) return 'text-fuchsia-400 font-extrabold';
    if (val === -3) return 'text-pink-500 font-bold';
    if (val === -4) return 'text-orange-400 font-bold';
    if (val === -5) return 'text-amber-500 font-bold';
    if (val <= -6) return 'text-rose-500 font-bold';

    // Uncalculated or true empty zero is handled separately.
    return 'text-slate-400 font-bold';
  };

  const remainingPositive = activeConfig.positiveBombs - counts.posFlags;
  const remainingNegative = activeConfig.negativeBombs - counts.negFlags;

  // Let's compute clearance parameters for Status Report sidebar card
  const totalSafeCells = (() => {
    let count = 0;
    board.forEach((row) => {
      row.forEach((cell) => {
        if (!cell.isBomb && !cell.isNegativeBomb) count++;
      });
    });
    return count;
  })();

  const revealedSafeCells = (() => {
    let count = 0;
    board.forEach((row) => {
      row.forEach((cell) => {
        if (cell.isRevealed && !cell.isBomb && !cell.isNegativeBomb) count++;
      });
    });
    return count;
  })();

  const clearancePercent = totalSafeCells > 0
    ? Math.min(100, Math.round((revealedSafeCells / totalSafeCells) * 100))
    : 0;

  const formatMinsAndSecs = (seconds: number): string => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const voidIndex = remainingPositive - remainingNegative;
  const formattedVoidIndex = voidIndex >= 0
    ? `+${String(voidIndex).padStart(2, '0')}`
    : `-${String(Math.abs(voidIndex)).padStart(2, '0')}`;

  return (
    <div className="flex flex-col min-h-screen bg-slate-100 font-sans text-slate-800 overflow-x-hidden selection:bg-indigo-100 selection:text-indigo-900">
      {/* Top Navigation / Header */}
      <header className="flex flex-col md:flex-row items-center justify-between px-6 sm:px-8 py-4 bg-white border-b border-slate-200 shadow-sm gap-4 z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded flex items-center justify-center shadow-lg transform rotate-2">
            <div className="w-4 h-4 bg-white rounded-full border-2 border-indigo-200 animate-pulse"></div>
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 uppercase">Minusweeper</h1>
            <p className="text-xs text-slate-500 font-semibold tracking-wide">v0.0</p>
          </div>
        </div>

        <div className="flex gap-6 sm:gap-8 justify-center items-center">
          <div className="flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Time</span>
            <span className="font-mono text-2xl text-indigo-700 font-bold transition-all duration-150">
              {formatMinsAndSecs(time)}
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Positive Bombs</span>
            <span className="font-mono text-2xl text-rose-650 font-bold">
              {String(Math.max(0, remainingPositive)).padStart(3, '0')}
            </span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Negative Bombs</span>
      
            <span className="font-mono text-2xl text-rose-650 font-bold">
              {String(Math.max(0, remainingNegative)).padStart(3, '0')}
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            initGame();
            sound.playClick();
          }}
          className="px-6 py-2.5 bg-slate-900 text-white rounded-lg font-bold text-xs hover:bg-slate-800 transition-all duration-150 shadow-md hover:shadow-lg active:scale-[0.98] cursor-pointer uppercase tracking-wider"
        >
          REROLL BOARD
        </button>
      </header>

      {/* Main Container split with sidebar and central grid */}
      <main className="flex-1 flex flex-col lg:flex-row p-6 md:p-8 gap-8 items-start justify-center max-w-7xl mx-auto w-full">
        {/* Sidebar Panel */}
        <aside className="w-full lg:w-64 flex flex-col gap-6 shrink-0 lg:sticky lg:top-8">
          {/* Field Intel Card */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-100 pb-2">
              <Info className="w-3.5 h-3.5 text-slate-500" />
              <span>Field Intel Map</span>
            </h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3.5 h-3.5 bg-rose-500 rounded border border-rose-600 shadow-sm flex items-center justify-center text-[9px] text-white font-extrabold">+</div>
                  <span className="text-sm font-semibold text-slate-700">Positive Bombs</span>
                </div>
                <span className="text-xs text-slate-450 font-medium">Surrounding tile number +1</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3.5 h-3.5 bg-purple-600 rounded border border-purple-700 shadow-sm flex items-center justify-center text-[9px] text-white font-extrabold">-</div>
                  <span className="text-sm font-semibold text-slate-700">Negative Bombs</span>
                </div>
                <span className="text-xs text-slate-450 font-medium">Surrounding tile number -1</span>
              </div>
              <hr className="border-slate-100" />
              <p className="text-xs text-slate-500 leading-relaxed font-sans">
                <strong className="text-slate-700 font-semibold">Mechanic:</strong> Negative bombs work exactly like normal bombs, except it subtracts surrounding tile number by one.
              </p>
            </div>
          </div>

          {/* Status Report Progress Card */}
          <div className="bg-indigo-50 p-5 rounded-2xl border border-indigo-100 shadow-xs">
            <h2 className="text-xs font-bold text-indigo-400 uppercase tracking-widest mb-1.5 flex items-center justify-between">
              <span>Status Report</span>
              {gameStatus === 'won' && <span className="text-emerald-600 bg-emerald-100/50 px-1.5 py-0.5 rounded text-[10px] font-bold">SECURED</span>}
              {gameStatus === 'lost' && <span className="text-rose-600 bg-rose-100/50 px-1.5 py-0.5 rounded text-[10px] font-bold">MUTED</span>}
            </h2>
            
            <div className="h-3.5 bg-indigo-200/50 rounded-full overflow-hidden mb-2 p-0.5 shadow-inner">
              <div
                className="h-full bg-indigo-600 rounded-full transition-all duration-500 ease-out"
                style={{ width: `${clearancePercent}%` }}
              ></div>
            </div>
            
            <div className="flex justify-between items-center text-xs">
              <span className="text-[10px] font-bold text-indigo-700 tracking-wide uppercase">
                {clearancePercent}% CLEARANCE
              </span>
              <span className="font-mono text-indigo-500 text-[10px] font-medium">
                {revealedSafeCells} / {totalSafeCells} SAFE
              </span>
            </div>
          </div>

          {/* Deployment Configuration presets */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
            <h2 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-100 pb-2">
              <Settings className="w-3.5 h-3.5 text-slate-400" />
              <span>Grid Parameters</span>
            </h2>
            <div className="grid grid-cols-1 gap-2">
              {(['easy', 'medium', 'hard'] as const).map((mode) => (
                <button
                  id={`btn-diff-${mode}`}
                  key={mode}
                  onClick={() => {
                    setDifficulty(mode);
                    setShowCustomConfig(false);
                    sound.playClick();
                  }}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold transition border cursor-pointer flex items-center justify-between ${
                    difficulty === mode && !showCustomConfig
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-600/10'
                      : 'bg-slate-50 hover:bg-slate-100 border-slate-150 text-slate-700 hover:text-slate-900'
                  }`}
                >
                  <span className="capitalize">{mode === 'easy' ? 'Easy (9x9)' : mode === 'medium' ? 'Medium (15x15)' : 'Expert Sector (16x30)'}</span>
                  {difficulty === mode && !showCustomConfig && <ChevronRight className="w-3 h-3 text-white animate-pulse" />}
                </button>
              ))}
              
              <button
                id="btn-diff-custom"
                onClick={() => {
                  setDifficulty('custom');
                  setShowCustomConfig(!showCustomConfig);
                  sound.playClick();
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold transition border cursor-pointer flex items-center justify-between ${
                  difficulty === 'custom'
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-md'
                    : 'bg-slate-50 hover:bg-slate-100 border-slate-150 text-slate-700 hover:text-slate-900'
                }`}
              >
                <span>Custom Size</span>
                <ChevronRight className={`w-3 h-3 transition-transform duration-200 ${showCustomConfig ? 'rotate-90' : ''}`} />
              </button>
            </div>

            {showCustomConfig && (
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-3 animate-fade-in text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 font-bold uppercase">Rows</label>
                    <input
                      type="number"
                      min={5}
                      max={20}
                      value={customRows}
                      onChange={(e) => setCustomRows(Math.min(20, Math.max(5, parseInt(e.target.value) || 5)))}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs text-slate-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 font-bold uppercase">Cols</label>
                    <input
                      type="number"
                      min={5}
                      max={24}
                      value={customCols}
                      onChange={(e) => setCustomCols(Math.min(24, Math.max(5, parseInt(e.target.value) || 5)))}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs text-slate-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 font-bold uppercase">Cores (+)</label>
                    <input
                      type="number"
                      min={1}
                      max={maxBombsForCustom}
                      value={customPosBombs}
                      onChange={(e) => setCustomPosBombs(Math.min(maxBombsForCustom, Math.max(1, parseInt(e.target.value) || 1)))}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs text-slate-800"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-slate-500 font-bold uppercase">Voids (-)</label>
                    <input
                      type="number"
                      min={0}
                      max={maxBombsForCustom}
                      value={customNegBombs}
                      onChange={(e) => setCustomNegBombs(Math.min(maxBombsForCustom, Math.max(0, parseInt(e.target.value) || 0)))}
                      className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 text-xs text-slate-800"
                    />
                  </div>
                </div>
                <button
                  onClick={handleCustomConfirm}
                  className="w-full py-1.5 bg-slate-900 text-white rounded-lg text-[10px] font-bold cursor-pointer hover:bg-slate-800 transition"
                >
                  DEACTIVATE AND REBUILD
                </button>
              </div>
            )}

            <div className="pt-2 flex gap-2">
              <button
                onClick={() => {
                  setShowHowTo(true);
                  sound.playClick();
                }}
                className="flex-1 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg border border-slate-200 text-center text-xs font-semibold cursor-pointer transition flex items-center justify-center gap-1"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Rules Manual</span>
              </button>

              <button
                onClick={handleToggleMute}
                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg border border-slate-200 cursor-pointer transition"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        </aside>

        {/* The Grid Container - Matching Void Sweeper Design Perfectly */}
        <div className="flex-1 w-full bg-slate-200 p-4 md:p-6 rounded-2xl shadow-xl border-4 border-slate-300 flex flex-col items-center justify-center overflow-hidden">
          
          {/* Sizing and Interactive assistance controls tab */}
          <div className="w-full flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-xs mb-6 text-xs text-slate-600">
            <div className="flex items-center space-x-2 w-full sm:w-auto">
              <span className="text-slate-500 font-medium">Zoom Factor:</span>
              <input
                type="range"
                min={24}
                max={48}
                value={cellSize}
                onChange={(e) => setCellSize(parseInt(e.target.value))}
                className="w-24 accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg appearance-none"
              />
              <span className="font-mono text-slate-400 font-semibold">{cellSize}px</span>
            </div>

            <div className="flex items-center gap-1 w-full sm:w-auto justify-end">
              <span className="text-slate-400 mr-1.5 uppercase font-bold text-[10px] tracking-wide">Touch Assist:</span>
              <button
                id="tool-mode-dig"
                onClick={() => setActiveTool('dig')}
                className={`px-3 py-1.5 rounded-lg border text-[11px] font-semibold transition cursor-pointer flex items-center gap-1 ${
                  activeTool === 'dig'
                    ? 'bg-slate-900 border-slate-900 text-white shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <MousePointer className="w-3 h-3" />
                <span>Dig Link</span>
              </button>
              <button
                id="tool-mode-flag-pos"
                onClick={() => setActiveTool('flag-positive')}
                className={`px-3 py-1.5 rounded-lg border text-[11px] font-semibold transition cursor-pointer flex items-center gap-1 ${
                  activeTool === 'flag-positive'
                    ? 'bg-rose-50 border-rose-200 text-rose-700 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-rose-50/50 hover:text-rose-600'
                }`}
              >
                <Flag className="w-3 h-3 text-rose-500 fill-rose-500" />
                <span>Flag Core</span>
              </button>
              <button
                id="tool-mode-flag-neg"
                onClick={() => setActiveTool('flag-negative')}
                className={`px-3 py-1.5 rounded-lg border text-[11px] font-semibold transition cursor-pointer flex items-center gap-1 ${
                  activeTool === 'flag-negative'
                    ? 'bg-purple-50 border-purple-200 text-purple-700 shadow-xs'
                    : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-purple-50/50 hover:text-purple-600'
                }`}
              >
                <Flag className="w-3 h-3 text-purple-500 fill-purple-500" />
                <span>Flag Void</span>
              </button>
            </div>
          </div>

          {/* Actual responsive game board frame */}
          <div className="w-full flex justify-center items-center overflow-auto p-4 bg-slate-300 rounded-xl border border-slate-400 shadow-inner scrollbar-thin">
            <div
              className={`grid gap-0.5 bg-slate-400 p-1.5 rounded ${gameStatus === 'lost' ? 'animate-pulse' : ''}`}
              style={{
                gridTemplateColumns: `repeat(${activeConfig.cols}, minmax(0, 1fr))`,
                width: `${activeConfig.cols * (cellSize + 2) + 12}px`
              }}
            >
              {board.map((rowCells, rIdx) =>
                rowCells.map((cell, cIdx) => {
                  const { isRevealed, flagState, neighborValue, isBomb, isNegativeBomb, adjacentPositive, adjacentNegative } = cell;

                  // Determine cellular backgrounds, animations, labels, and borders
                  let cellClass = "flex items-center justify-center font-sans transition-all duration-75 relative select-none ";
                  let cellContent = null;

                  const isClickedExplosion = explodedCell && explodedCell.row === rIdx && explodedCell.col === cIdx;

                  if (isRevealed) {
                    if (isBomb) {
                      if (isClickedExplosion) {
                        cellClass += "bg-gradient-to-br from-rose-600 to-red-700 text-white rounded-sm border-2 border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.7)] scale-95 animate-bounce z-10";
                      } else {
                        cellClass += "bg-rose-500 text-white rounded-sm border border-rose-650 shadow-md scale-95 opacity-90";
                      }
                      cellContent = (
                        <div className="relative flex items-center justify-center w-5 h-5 antialiased">
                          <div className="absolute w-2 h-2 bg-white rounded-full"></div>
                          <div className="w-1 h-3 bg-white rotate-45 absolute rounded-full"></div>
                          <div className="w-1 h-3 bg-white -rotate-45 absolute rounded-full"></div>
                        </div>
                      );
                    } else if (isNegativeBomb) {
                      if (isClickedExplosion) {
                        cellClass += "bg-slate-950 border-2 border-purple-500 flex items-center justify-center rounded-sm overflow-hidden scale-95 shadow-[0_0_15px_rgba(147,51,234,0.7)] animate-pulse z-10";
                      } else {
                        cellClass += "bg-slate-900 border border-slate-950 flex items-center justify-center rounded-sm overflow-hidden scale-95 opacity-90";
                      }
                      cellContent = (
                        <div className="relative flex items-center justify-center w-full h-full">
                          <div className="w-4 h-4 bg-purple-600 blur-[1px] animate-pulse rounded-full shadow-[0_0_8px_rgba(147,51,234,1)]"></div>
                        </div>
                      );
                    } else {
                      // Safe revealed cell
                      cellClass += "bg-slate-200 border border-slate-300 font-black text-lg";

                      // 0 tile vs numbers
                      if (adjacentPositive === 0 && adjacentNegative === 0) {
                        cellContent = null;
                      } else {
                        const label = neighborValue > 0 ? `+${neighborValue}` : `${neighborValue}`;
                        const colorClass = getCellTextColorClass(neighborValue);
                        cellContent = (
                          <span className={`text-lg font-black tracking-tighter ${colorClass}`}>
                            {label === '0' ? '0' : label}
                          </span>
                        );
                      }
                    }
                  } else {
                    // Unrevealed states
                    const isFalsePositive = gameStatus === 'lost' && (flagState === 'positive' || flagState === 'negative') && !isBomb && !isNegativeBomb;
                    const isMisidentified = gameStatus === 'lost' && (
                      (isBomb && flagState === 'negative') ||
                      (isNegativeBomb && flagState === 'positive')
                    );

                    if (isFalsePositive) {
                      // False positive (incorrectly flagged safe cell on game over)
                      cellClass += "bg-rose-50 border border-rose-350 flex items-center justify-center rounded-sm scale-95 shadow-inner overflow-hidden";
                      cellContent = (
                        <div className="relative w-full h-full flex items-center justify-center">
                          {/* Muted Flag underneath */}
                          <div className="relative opacity-40 flex items-center justify-center scale-90">
                            {flagState === 'positive' ? (
                              <div className="relative flex items-center justify-center">
                                <Flag className="text-rose-500 fill-rose-500" style={{ width: `${cellSize * 0.4}px`, height: `${cellSize * 0.4}px` }} />
                                <span className="absolute -top-1 -right-1 font-mono text-[8px] font-black leading-none bg-white border border-rose-200 px-0.5 rounded text-rose-600 transform scale-75 opacity-65">+</span>
                              </div>
                            ) : (
                              <div className="relative flex items-center justify-center">
                                <Flag className="text-purple-600 fill-purple-600" style={{ width: `${cellSize * 0.4}px`, height: `${cellSize * 0.4}px` }} />
                                <span className="absolute -top-1 -right-1 font-mono text-[8px] font-black leading-none bg-white border border-purple-200 px-0.5 rounded text-purple-600 transform scale-75 opacity-65">-</span>
                              </div>
                            )}
                          </div>
                          {/* Superimposed bold red Cross representing mismatch */}
                          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10 p-1">
                            <svg className="w-full h-full text-rose-650 drop-shadow-[0_1px_1px_rgba(0,0,0,0.15)] stroke-[3]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3.5">
                              <line x1="3" y1="3" x2="21" y2="21" />
                              <line x1="21" y1="3" x2="3" y2="21" />
                            </svg>
                          </div>
                        </div>
                      );
                    } else if (isMisidentified) {
                      // Wrong polarity flag on real bomb on game over
                      cellClass += "bg-amber-50 border border-amber-500 flex items-center justify-center rounded-sm scale-95 shadow-sm overflow-hidden";
                      cellContent = (
                        <div className="relative w-full h-full flex items-center justify-center">
                          {/* Small ghost shape of the underlying bomb type */}
                          <div className="absolute inset-0 flex items-center justify-center opacity-25 z-0">
                            {isBomb ? (
                              <div className="w-4 h-4 bg-rose-450 rounded-full flex items-center justify-center text-white font-bold text-[8px]">+</div>
                            ) : (
                              <div className="w-3.5 h-3.5 bg-purple-550 rounded-full blur-[1px]"></div>
                            )}
                          </div>

                          {/* Semi-transparent view of the wrong flag they put */}
                          <div className="relative z-10 flex items-center justify-center scale-90 origin-center opacity-50">
                            {flagState === 'positive' ? (
                              <div className="relative">
                                <Flag className="text-rose-500 fill-rose-500" style={{ width: `${cellSize * 0.4}px`, height: `${cellSize * 0.4}px` }} />
                                <span className="absolute -top-1 -right-1 font-mono text-[8px] font-black leading-none bg-white border border-rose-200 px-0.5 rounded text-rose-600 transform scale-75 opacity-65">+</span>
                              </div>
                            ) : (
                              <div className="relative">
                                <Flag className="text-purple-600 fill-purple-600" style={{ width: `${cellSize * 0.4}px`, height: `${cellSize * 0.4}px` }} />
                                <span className="absolute -top-1 -right-1 font-mono text-[8px] font-black leading-none bg-white border border-purple-200 px-0.5 rounded text-purple-600 transform scale-75 opacity-65">-</span>
                              </div>
                            )}
                          </div>

                          {/* Red cross line indicating it was wrong type */}
                          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
                            <svg className="w-full h-full text-rose-650 drop-shadow-[0_1px_1px_rgba(0,0,0,0.1)] stroke-[3]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                              <line x1="3" y1="3" x2="21" y2="21" />
                            </svg>
                          </div>

                          {/* Corner indicator showing what type of bomb was actually there */}
                          <div className="absolute bottom-0 right-0 z-30 bg-indigo-600 text-white rounded-[2px] font-mono font-black text-[7px] leading-tight px-0.5 scale-90 shadow-xs border border-white">
                            {isBomb ? '+' : '-'}
                          </div>
                        </div>
                      );
                    } else {
                      // Covered cells with classic 3D retro borders
                      cellClass += "bg-slate-300 border-2 border-t-white border-l-white border-b-slate-500 border-r-slate-500 rounded-sm hover:bg-slate-250 cursor-pointer active:border-slate-300 shadow-sm";

                      if (flagState === 'positive') {
                        cellContent = (
                          <div className="relative flex items-center justify-center" title="Core flag">
                            <Flag className="text-rose-500 fill-rose-500" style={{ width: `${cellSize * 0.45}px`, height: `${cellSize * 0.45}px` }} />
                            <span className="absolute -top-1 -right-1 font-mono text-[8px] font-black leading-none bg-white border border-rose-200 px-0.5 rounded text-rose-600 shadow-xs">+</span>
                          </div>
                        );
                      } else if (flagState === 'negative') {
                        cellContent = (
                          <div className="relative flex items-center justify-center" title="Void flag">
                            <Flag className="text-purple-600 fill-purple-600" style={{ width: `${cellSize * 0.45}px`, height: `${cellSize * 0.45}px` }} />
                            <span className="absolute -top-1 -right-1 font-mono text-[8px] font-black leading-none bg-white border border-purple-200 px-0.5 rounded text-purple-600 shadow-xs">-</span>
                          </div>
                        );
                      } else if (flagState === 'question') {
                        cellContent = <span className="text-amber-600 font-extrabold text-[13px]">?</span>;
                      }
                    }
                  }

                  return (
                    <button
                      id={`cell-${rIdx}-${cIdx}`}
                      key={`${rIdx}-${cIdx}`}
                      onClick={() => handleCellPrimaryAction(rIdx, cIdx)}
                      onContextMenu={(e) => handleFlagCycle(rIdx, cIdx, e)}
                      onMouseDown={() => {
                        if (!isRevealed && gameStatus !== 'lost' && gameStatus !== 'won') {
                          setIsClickingCell(true);
                        }
                      }}
                      onMouseUp={() => setIsClickingCell(false)}
                      className={cellClass}
                      style={{
                        width: `${cellSize}px`,
                        height: `${cellSize}px`
                      }}
                      aria-label={`row ${rIdx} column ${cIdx}`}
                    >
                      {cellContent}
                    </button>
                  );
                })
              )}
            </div>
          </div>

          <div className="w-full flex items-center justify-between text-[11px] text-slate-500 pt-3">
            <span className="flex items-center gap-1"><Info className="w-3.5 h-3.5 text-slate-400" /> Right-click cells to cycle Flag Core, Void, ?, and none.</span>
            {difficulty !== 'custom' && highScores[difficulty] && (
              <span className="text-amber-600 font-bold flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5" /> Best Record: {highScores[difficulty]}s
              </span>
            )}
          </div>
        </div>
      </main>

      {/* Retro Professional System Footer */}
      <footer className="bg-slate-900 text-slate-400 text-[10px] px-8 py-3.5 font-mono flex flex-col md:flex-row justify-between items-center gap-3 mt-auto">
        <div className="flex gap-4">
          <span>SYSTEM: NORMAL</span>
          <span>GRID_SEED: NEG-SEC-{activeConfig.rows}x{activeConfig.cols}</span>
          <span className="text-emerald-500 animate-pulse flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>● ONLINE</span>
          </span>
        </div>
        <div className="flex gap-4 uppercase font-bold tracking-wider text-slate-500">
          <span>Left-Click: Reveal</span>
          <span>Right-Click: Cycle mark</span>
          <span>Click Revealed: Chord Expand</span>
        </div>
      </footer>

      {/* Guide/Instructions Overlay Modal */}
      <HowToPlay isOpen={showHowTo} onClose={() => setShowHowTo(false)} />
    </div>
  );
}
