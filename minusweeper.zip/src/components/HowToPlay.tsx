/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { HelpCircle, Bomb, Flag, X, ArrowRight, Zap, Target } from 'lucide-react';

interface HowToPlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function HowToPlay({ isOpen, onClose }: HowToPlayProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-slate-800 text-slate-100 rounded-2xl border border-slate-700 max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-700 sticky top-0 bg-slate-800 z-10">
          <div className="flex items-center space-x-3">
            <HelpCircle className="w-6 h-6 text-indigo-400" />
            <h2 id="how-to-play-title" className="text-xl font-bold tracking-tight">How to Play Minesweeper Negative</h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 hover:bg-slate-700/60 p-2 rounded-xl transition-colors duration-150"
            aria-label="Close rules modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Intro */}
          <p className="text-slate-300 text-sm leading-relaxed">
            Welcome to <strong className="text-indigo-400">Minesweeper Negative</strong>! This is a unique variant of the classic game that expands on deductive logic using simple arithmetic. There are two kinds of bombs hidden under the grid.
          </p>

          {/* Grid Layout of Bombs */}
          <div className="grid md:grid-cols-2 gap-4">
            {/* Positive Bomb */}
            <div className="p-4 bg-slate-750 rounded-xl border border-rose-500/20 space-y-3">
              <div className="flex items-center space-x-2 text-rose-400 font-semibold">
                <div className="p-1.5 bg-rose-500/10 rounded-lg">
                  <Bomb className="w-5 h-5" />
                </div>
                <span>Positive Bomb (+1)</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Acts as a standard mine. Adds <strong className="text-rose-400 font-medium">+1</strong> to the neighbor values of all adjacent tiles. Right-click once to flag as <span className="text-rose-400 font-medium">🚩 (+)</span>.
              </p>
            </div>

            {/* Negative Bomb */}
            <div className="p-4 bg-slate-750 rounded-xl border border-cyan-500/20 space-y-3">
              <div className="flex items-center space-x-2 text-cyan-400 font-semibold">
                <div className="p-1.5 bg-cyan-500/10 rounded-lg animate-pulse">
                  <Bomb className="w-5 h-5 text-cyan-400 rotate-180" />
                </div>
                <span>Negative Bomb (-1)</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                A dark-energy mine. Subtracts <strong className="text-cyan-400 font-medium">-1</strong> from the neighbor values of adjacent tiles. Right-click twice to flag as <span className="text-cyan-400 font-medium">🏳️ (-)</span>.
              </p>
            </div>
          </div>

          {/* Mathematical Examples */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-200">The Net Value Arithmetic</h3>
            <p className="text-xs text-slate-400">
              Surrounding cells display the sum of adjacent positive bombs minus adjacent negative bombs:
            </p>

            <div className="bg-slate-900/60 rounded-xl p-4 border border-slate-700/50 space-y-3 text-xs font-mono">
              <div className="flex items-center justify-between text-slate-300">
                <div className="flex items-center space-x-2">
                  <span className="bg-rose-500/15 text-rose-400 px-1.5 py-0.5 rounded">2 Bombs (+)</span>
                  <span>+</span>
                  <span className="bg-slate-700 text-slate-400 px-1.5 py-0.5 rounded">0 Negatives</span>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500" />
                <span className="font-bold text-green-400 text-sm bg-green-500/10 px-2 py-0.5 rounded">+2</span>
              </div>

              <div className="flex items-center justify-between text-slate-300">
                <div className="flex items-center space-x-2">
                  <span className="bg-slate-700 text-slate-400 px-1.5 py-0.5 rounded">0 Bombs</span>
                  <span>+</span>
                  <span className="bg-cyan-500/15 text-cyan-400 px-1.5 py-0.5 rounded">2 Negatives (-)</span>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500" />
                <span className="font-bold text-violet-400 text-sm bg-violet-500/10 px-2 py-0.5 rounded">-2</span>
              </div>

              <div className="flex items-center justify-between text-slate-300">
                <div className="flex items-center space-x-2">
                  <span className="bg-rose-500/15 text-rose-400 px-1.5 py-0.5 rounded">1 Bomb (+)</span>
                  <span>+</span>
                  <span className="bg-cyan-500/15 text-cyan-400 px-1.5 py-0.5 rounded">1 Negative (-)</span>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-500" />
                <span className="font-bold text-slate-200 text-sm bg-slate-700 px-2 py-0.5 rounded">0</span>
              </div>
            </div>
          </div>

          {/* Key Rule: True Zero vs Net Zero */}
          <div className="bg-amber-950/25 border border-amber-500/20 rounded-xl p-4 space-y-2 text-xs">
            <div className="flex items-center space-x-2 text-amber-400 font-semibold mb-1">
              <Zap className="w-4 h-4" />
              <span>Crucial Rule: True Zero vs. Net Zero</span>
            </div>
            <ul className="list-disc pl-5 space-y-1.5 text-slate-300 leading-relaxed">
              <li>
                <strong className="text-white">True Zero (Blank Tile)</strong>: Has 0 adjacent positive bombs and 0 adjacent negative bombs. Clicking this is 100% safe and triggers a cascading auto-reveal of neighbors.
              </li>
              <li>
                <strong className="text-white">Net Zero (Visible "0")</strong>: Has an equal number of positive and negative adjacent bombs (e.g. 1 of each), resulting in a sum of 0. <span className="text-amber-300">It does NOT trigger auto-reveal</span> because bomb hazard exists directly adjacent to it! You must solve it manually.
              </li>
            </ul>
          </div>

          {/* Action flow */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="p-3 bg-slate-800 rounded-lg border border-slate-700/60">
              <div className="font-semibold text-slate-200 mb-1">🖱️ Controls</div>
              <ul className="space-y-1 text-slate-400 pl-4 list-disc">
                <li><strong className="text-slate-300">Left Click</strong>: Reveal Cell</li>
                <li><strong className="text-slate-300">Right Click</strong>: Cycle Flag (+ flag, - flag, ?, none)</li>
                <li><strong className="text-slate-300">Left+Right (or Shift+Click)</strong>: Chord reveal unflagged neighbors when adjacent flags correctly match the adjacent counts.</li>
              </ul>
            </div>
            <div className="p-3 bg-slate-800 rounded-lg border border-slate-700/60">
              <div className="font-semibold text-slate-200 mb-1">🏆 Win Condition</div>
              <p className="text-slate-400 leading-relaxed">
                Safely reveal all cells that are NOT positive or negative bombs. You do not need to flag them to win, but flagging helps you solve the grid without blowing up!
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-700 bg-slate-850 flex justify-end">
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-xl transition duration-150 flex items-center justify-center space-x-2 shadow-md hover:shadow-indigo-600/10 cursor-pointer"
          >
            <Target className="w-4 h-4" />
            <span>Start Solving</span>
          </button>
        </div>
      </div>
    </div>
  );
}
